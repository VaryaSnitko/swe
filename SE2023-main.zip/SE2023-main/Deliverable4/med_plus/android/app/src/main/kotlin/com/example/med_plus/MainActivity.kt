package com.example.med_plus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
