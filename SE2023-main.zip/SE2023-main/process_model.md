The Agile Process Model is determined to be most suitable for developing this project. This process model utilizes small, highly motivated team members, to deliver operational software increments in a timely manner and satisfy the customer’s requirements. The steps within the process model include communication, planning, modeling, construction and deployment, with minimal tasks set that push the project towards construction and delivery. 

It was decided upon based on the following reasons:
1. The customer’s need may change: The agile process model acknowledges this uncertainty. Working in iterations allows us to focus on producing our current set of features and add additional components in the future. The cost of change is minimal with an agile approach to the project.
2. Limited Budget: Given our small budget, by utilizing multiple iterations, new changes can be implemented at very little cost.
Short and Flexible Timeline: We are working in a short time frame, 4 months. Therefore it is critical to get a functioning app deployed, which is prioritized over comprehensive documentation and process. Therefore, a “good enough” approach towards documentation would satisfy the need of this project.
3. Small and Focused project: Given that the project is small, the Agile process is suitable because we will not have too large of a scope to develop and possibly change. 
The Agile method of construction that will be utilized is Extreme Programming because of the following reasons:
1. Minimizes the time spent on testing towards the end of the iteration as pair programming ensures testing in parallel while constructing the application.
2. Allows increased modularity as each unit is testing individually. 
This method will be supported by:
1. Pair Programming: Teams of two that work together at one computer to create code. We are a small team of 4. Pair programming supports real-time quality assurance. 
2. Continuous Integration: And by having each team continuously integrate their components it is possible to uncover compatibility and interfacing issues early. 
3. Testing: Tests are developed before code is written. Allows for testing during the coding phase to ensure that the system acts as required. 
